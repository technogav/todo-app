/*
* Author: Gavin Murphy
* Assignment: WE4 Mobile Web Applications, Digital Skills Academy
* Date : 2016/09/12
* Ref: App is losely based on a treehouse tutorial I completed in Feburary, however it has been improved so it has extra functionality and added on to so it meets the criteria for the asseesment
*/
'use strict';
//declare a service called datasERVICE
angular.module('todoListApp')
.service('dataService', function($http) {

//method to 'get' the todos from a restful API in the form of json    
  this.getTodos = function(callback){
    $http.get('mock/todos.txt')
    .then(callback);
  };

//method to delete the todo from the rest API 
  this.deleteTodo = function(todo) {
    console.log("The " + todo.name + " todo has been deleted!");
//use angular ajax to send the delete todo to the php script which will update the json file
    $http({
         method: 'POST',
         url: 'deleteFromJson.php',
         data: {'name': todo.name}
     })
     .success(function(){
          console.log('deletes');
     });
   
  };
//method to save the todo in the rest api
  this.saveTodos = function(todos) {
    console.log(todos.length + " todos have been saved!");
  };
});