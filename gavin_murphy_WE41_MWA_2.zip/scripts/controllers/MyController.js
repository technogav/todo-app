/*
* Author: Gavin Murphy
* Assignment: WE4 Mobile Web Applications, Digital Skills Academy
* Date : 2016/09/12
* Ref: App is losely based on a treehouse tutorial however it has been improved so it has extra functionality and added on to
so it meets the criteria for the asseesment
*/
'use strict';
//declare angular app
angular.module("todoListApp", []);

//declare controller
angular.module('todoListApp')
.controller('mainCtrl', function($scope, dataService, $http) {

//add a todo to scope object   
  $scope.addTodo = function() {
    var todo = {name: $scope.inputTodo};
    $scope.todos.unshift(todo);
//use angular ajax to send todo item to a php script which will rewrite the json file    
    $http({
         method: 'POST',
         url: 'writeToJson.php',
         data: {'name': $scope.inputTodo}
     })
     .success(function(){
          console.log('todo added');
     });     
  };

//fetch data from the service data.js and copy it to scope object 
  dataService.getTodos(function(response) { 
      console.log(response.data);  
      $scope.todos = response.data;
    });

//call the delete todo function in the service which will update the json
  $scope.deleteTodo = function(todo, $index) {
    dataService.deleteTodo(todo, $index);
//delete todo from the scope object   
    $scope.todos.splice($index, 1);
  };

//send todo to service to be saved
  $scope.saveTodos = function(todo) { 
    dataService.saveTodos(todo);
  };
});